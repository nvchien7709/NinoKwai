<!-- First ensure you installed the latest version of fs-extra -->
<!-- If your bug still exists please fill out the following information if it applies to your issue: -->
<!-- Please check if you have installed a supported version of Node.js as written in "engines" in the package.json -->
- **Operating System:**
- **Node.js version:**
- **`fs-extra` version:**
